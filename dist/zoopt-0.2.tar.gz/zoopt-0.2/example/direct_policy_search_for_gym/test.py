import numpy as np
a = np.zeros((4, ))
print a